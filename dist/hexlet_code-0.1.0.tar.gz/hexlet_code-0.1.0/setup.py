# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-games = brain_games.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Di-Nov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Di-Nov/python-project-49/actions)\n\n<a href="https://codeclimate.com/github/Di-Nov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/057743d34e8d9a27af5f/maintainability" /></a>',
    'author': 'Dmitry Nov.',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8.1,<4.0.0',
}


setup(**setup_kwargs)
