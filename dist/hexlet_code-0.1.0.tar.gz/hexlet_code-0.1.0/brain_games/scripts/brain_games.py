#!/usr/bin/env python3

def xxx():
    print('Welcome to the Brain Games!')

def main():
    xxx()

if __name__ == '__main__':
    main()
