### Hexlet tests and linter status:
[![Actions Status](https://github.com/Di-Nov/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Di-Nov/python-project-49/actions)

<a href="https://codeclimate.com/github/Di-Nov/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/057743d34e8d9a27af5f/maintainability" /></a>